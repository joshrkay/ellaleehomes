# Apply this PR with `git apply`

`changes.patch` is a unified diff against the repo's default branch
`claude/implement-ella-lee-homes-lh0JL` (HEAD at generation time).

## Steps
```bash
git clone https://github.com/joshrkay/ellaleehomes.git   # or use your existing clone
cd ellaleehomes
git checkout claude/implement-ella-lee-homes-lh0JL
git pull

# new branch for the PR
git checkout -b feature/full-site-pages

# check it applies cleanly first (no output = clean)
git apply --check changes.patch

# apply, then commit
git apply changes.patch

# copy the new logo image in (binary — not carried by the text patch)
cp uploads/Wordmark_Inline_Cream.png /path/to/ellaleehomes/uploads/

git add -A
git commit -m "Add full site + deploy config; nav CTA → Inquire; hero wordmark image"

# push and open the PR
git push -u origin feature/full-site-pages
```
Open the compare URL GitHub prints (base `claude/implement-ella-lee-homes-lh0JL`)
and paste `PULL_REQUEST.md` as the description.

## What's in the patch
- **22 new files** — 17 new pages, `robots.txt`, `sitemap.xml`,
  `assets/article.css`, `assets/site-nav-dd.js`, `assets/site-nav-contrast.js`
- **7 modified files** — `src/index.html`, `src/our-story.html`, `src/process.html`,
  `src/project.html`, `src/projects.html`, `assets/site-footer.css`, `assets/site-nav.css`

Modified files use full-content replacement hunks, so the patch only applies against
the exact base branch above. If `git apply --check` fails, your branch has moved on —
tell me and I'll regenerate against the new HEAD.

## New binary asset (copy manually)
`uploads/Wordmark_Inline_Cream.png` is the cream inline wordmark now used as the
homepage hero intro (`src/index.html`). `git apply` can't carry binaries, so copy it
from this package's `uploads/` folder into the repo's `uploads/` folder before
committing (see step above).

## If `git apply` reports whitespace warnings
They're harmless; you can force with `git apply --whitespace=nowarn changes.patch`.
