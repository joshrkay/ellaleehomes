# Add full site page set + complete the shared nav/asset system

## Summary
Expands the site from the original 5 pages to a complete 22-page set, updates the
existing core pages, and brings the repo-root `assets/` folder up to the full,
current asset system used by every page (dropdown nav, auto nav contrast, article
styles). Shared partials are included.

## New pages (`src/`)
- `sell.html`, `contact.html`, `client-portal.html`, `investors.html`, `why-us.html`, `stories.html`
- `faq.html`, `privacy.html`, `terms.html`, `disclaimer.html`, `our-story-print.html`
- Blog/guides: `steps-to-building-a-custom-home.html`,
  `how-to-find-a-custom-home-builder.html`,
  `is-custom-home-building-a-good-investment.html`,
  `exploring-the-costs-of-building-your-dream-home-a-comprehensive-guide.html`,
  `new-luxury-essentials-custom-homes-arizona.html`,
  `why-choosing-a-professional-home-builder-matters-for-your-custom-house.html`
- SEO: `robots.txt`, `sitemap.xml`

## Updated pages (`src/`)
- `index.html`, `our-story.html`, `process.html`, `project.html`, `projects.html`

## Assets (`assets/`) — now the complete set
Previously the repo only had 4 asset files, but every page references two scripts
that weren't committed. This PR adds/updates them so pages ship with zero 404s:

- **`site-nav-dd.js`** *(new)* — desktop "Learn" dropdown + mobile hamburger menu,
  hide-on-scroll behaviour. Referenced by every page.
- **`site-nav-contrast.js`** *(new)* — samples the background behind the nav and
  toggles `#nav.nav-on-light` / `.nav-on-dark` so the menu stays legible over
  light and dark sections. Referenced by every page.
- **`article.css`** *(new)* — shared styles for the blog/guide pages.
- **`site-nav.css`** *(updated)* — adds the Learn dropdown panel, mobile overlay,
  and nav-contrast styles.
- `site-cursor.css`, `site-cursor.js`, `site-footer.css` — shared cursor + footer.

## Deploy config (repo root)
- `.github/workflows/deploy.yml` — builds (`npm run build`) and publishes `dist/`
  to GitHub Pages on push to the default branch (enable Pages → "GitHub Actions").
- `netlify.toml` / `vercel.json` — build command `npm run build`, output `dist`;
  read automatically if the repo is connected to Netlify or Vercel.

## Partials (`partials/`)
- `nav.html`, `footer.html`, `cursor.html`

## Notes
- Most photography is served from `https://ellaleehomes.com/wp-content/uploads/…`
  (live WordPress CDN). A few local images (`uploads/Monogram_Navy.png`,
  `uploads/IMG_*.jpg`) are already in the repo and unchanged.
- Per the repo README, `npm run build` copies `assets/` and `uploads/` alongside the
  pages into `dist/`, so pages resolve `assets/…` correctly once built.
